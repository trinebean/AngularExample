angular.module('myApp.walking', ['ngRoute'])
.service('characters', function() {
    this.getCharacters = function () {
        console.log("wtf");
        return [{name: 'Glenn', status: 'Alive'},{name: 'Governor', status: 'Dead'},{name: 'Maggie', status: 'Alive'}];
    }
});